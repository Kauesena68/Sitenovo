import { FC } from "react"
import styles from './styles.module.scss'

const App: FC = () => {
  return (
    <div className={styles.app}>
      <h1>Coming Soon</h1>
    </div>
  )
}

export default App